function usdToBgn (usd) {
let bgn = usd * 1.79549;
console.log(bgn);

}


usdToBgn (12.5);